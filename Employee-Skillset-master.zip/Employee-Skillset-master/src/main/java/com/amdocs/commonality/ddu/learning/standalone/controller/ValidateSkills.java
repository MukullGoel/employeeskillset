package com.amdocs.commonality.ddu.learning.standalone.controller;

import com.amdocs.commonality.ddu.learning.standalone.controller.Models.Models.EmployeeSkillset;
import com.amdocs.commonality.ddu.learning.standalone.service.ValidateSkillsApplicationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ValidateSkills {
	@AutoWired
	ValidateSkillsApplicationService validateSkillsApplicationService;

	@PostMapping("/employeemanagement/v1/validateEmployeeSkills")
	public ResponseEntity validateSkills(@ResponseBody EmployeeSkillset employeeSkillset){
		EmployeeMissingSkillset employeeMissingSkillset = validateSkillsApplicationService
				.validateSkills(employeeSkillset);
		return new ResponseEntity(employeeSkillset, HttpStatus.CREATED);

	}


}
