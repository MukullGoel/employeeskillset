package com.amdocs.commonality.ddu.learning.standalone.service;

import com.amdocs.commonality.ddu.learning.standalone.controller.Models.Models.EmployeeSkillset;
import com.amdocs.commonality.ddu.learning.standalone.model.EmployeeMissingSkillset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ValidateSkillsApplicationService {

    @Autowired
    EmployeeMissingSkillset employeeMissingSkillset;

    public EmployeeMissingSkillset validateSkills(EmployeeSkillset employeeSkillset) {
        employeeMissingSkillset.setEmpId(employeeSkillset.getEmpId());
        employeeSkillset.getRequiredSkills().removeIf(skill -> employeeSkillset.getActualSkills().stream()
                .anyMatch(skill2 -> skill2.equalsIgnoreCase(skill)));
        employeeMissingSkillset.setMissingSkills(employeeSkillset.getRequiredSkills());
        return employeeMissingSkillset;
    }

}
